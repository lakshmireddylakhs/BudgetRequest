# Budget Management System

Spring Boot application for budget approval workflow.
