package com.example.BudgetModel;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private double currentBudget;
    private double yearlyAllocation;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getCurrentBudget() {
        return currentBudget;
    }
    public void setCurrentBudget(double currentBudget) {
        this.currentBudget = currentBudget;
    }
    public double getYearlyAllocation() {
        return yearlyAllocation;
    }
    public void setYearlyAllocation(double yearlyAllocation) {
        this.yearlyAllocation = yearlyAllocation;
    }
}

