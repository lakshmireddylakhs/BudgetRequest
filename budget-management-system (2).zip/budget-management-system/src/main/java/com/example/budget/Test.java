package com.example.budget;

public class Test {
	
	public static boolean isPrime(int number) {
		if(number<=1) {
			return false;
		}
		
		if(number ==2) {
			return true;
		}
		
		if(number % 2 ==0) {
			return false;
		}
		for(int i = 3; i*1<number; i +=2) {
			
			if(number % i==0) {
				return false;
			}
		}
		
		return true;
	}
	
	public static void main (String[] args) {
		int number = 29;
		if(isPrime(number)) {
			System.out.println(number + "is  prime number");
			
		}else {
			System.out.println(number + "is not  prime number");
			
		}
	}

}
