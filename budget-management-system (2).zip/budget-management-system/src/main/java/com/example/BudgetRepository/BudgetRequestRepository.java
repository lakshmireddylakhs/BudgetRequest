package com.example.BudgetRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BudgetModel.BudgetRequest;

import java.time.LocalDateTime;
import java.util.List;

public interface BudgetRequestRepository extends JpaRepository<BudgetRequest, Long> {
    List<BudgetRequest> findByStatus(com.example.BudgetModel.BudgetRequest.Status pending);
    boolean existsByPurposeAndRequestedByAndDateCreatedAfter(String purpose, String requestedBy, LocalDateTime dateCreated);
}
