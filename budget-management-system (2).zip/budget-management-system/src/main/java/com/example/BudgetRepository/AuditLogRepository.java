package com.example.BudgetRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BudgetModel.AuditLog;

import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findByEntityType(String entityType);
}