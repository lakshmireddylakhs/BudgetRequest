package com.example.BudgetRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BudgetModel.Department;


public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
