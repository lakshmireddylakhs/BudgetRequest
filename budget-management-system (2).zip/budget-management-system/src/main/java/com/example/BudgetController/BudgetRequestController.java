package com.example.BudgetController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.BudgetModel.AuditLog;
import com.example.BudgetModel.BudgetRequest;
import com.example.BudgetModel.Department;
import com.example.BudgetRepository.DepartmentRepository;
import com.example.BudgetService.BudgetRequestService;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BudgetRequestController {

    @Autowired
    private BudgetRequestService budgetRequestService;
    
    @Autowired
    private DepartmentRepository departmentRepository;

    @PostMapping("/budget-request")
    public BudgetRequest createBudgetRequest(@RequestBody BudgetRequest request) {
        return budgetRequestService.submitRequest(request);
    }



    @PutMapping("/budget-request/{id}/approve")
    public BudgetRequest approveRequest(@PathVariable Long id, @RequestParam String manager) {
        return budgetRequestService.approveRequest(id, manager);
    }

    @PutMapping("/budget-request/{id}/reject")
    public BudgetRequest rejectRequest(@PathVariable Long id, @RequestParam String manager) {
        return budgetRequestService.rejectRequest(id, manager);
    }

    @GetMapping("/budget-request/pending")
    public List<BudgetRequest> getPendingRequests() {
        return budgetRequestService.getPendingRequests();
    }

    @GetMapping("/audit-logs")
    public List<AuditLog> getAuditLogs(@RequestParam String entityType) {
        return budgetRequestService.getAuditLogs(entityType);
    }
}

