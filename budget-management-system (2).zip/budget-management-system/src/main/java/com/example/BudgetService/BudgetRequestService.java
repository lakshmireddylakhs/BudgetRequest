package com.example.BudgetService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BudgetModel.AuditLog;
import com.example.BudgetModel.BudgetRequest;
import com.example.BudgetModel.BudgetRequest.Status;
import com.example.BudgetModel.Department;
import com.example.BudgetRepository.AuditLogRepository;
import com.example.BudgetRepository.BudgetRequestRepository;
import com.example.BudgetRepository.DepartmentRepository;



@Service
public class BudgetRequestService {

    @Autowired
    private BudgetRequestRepository budgetRequestRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    public BudgetRequest submitRequest(BudgetRequest request) {
        // Validate amount
        Double amount = request.getRequestedAmount();
        if (amount == null || amount <= 0) {
            throw new IllegalArgumentException("Requested amount must be positive");
        }

        // Validate required fields
        if (request.getPurpose() == null || request.getRequestedBy() == null || request.getDepartment() == null) {
            throw new IllegalArgumentException("Purpose, RequestedBy, and Department must not be null");
        }

        // Fetch and validate department (it will now always exist via the DepartmentController API)
        Department dept = departmentRepository.findById(request.getDepartment().getId())
            .orElseThrow(() -> new IllegalArgumentException("Invalid Department ID"));
        request.setDepartment(dept);

        // Check for duplicates
        boolean isDuplicate = budgetRequestRepository.existsByPurposeAndRequestedByAndDateCreatedAfter(
            request.getPurpose(),
            request.getRequestedBy(),
            LocalDateTime.now().minusDays(7)
        );

        if (isDuplicate) {
            throw new IllegalArgumentException("Duplicate request for the same purpose within 7 days");
        }

        request.setStatus(Status.PENDING);
        request.setDateCreated(LocalDateTime.now());
        request.setLastUpdated(LocalDateTime.now());

        return budgetRequestRepository.save(request);
    }    
    public Department createDepartment(Department department) {
        return departmentRepository.save(department);
    }
    
    
    public BudgetRequest approveRequest(Long id, String managerUsername) {
        BudgetRequest request = getRequestOrThrow(id);

        if (request.getStatus() != Status.PENDING) {
            throw new IllegalStateException("Only pending requests can be approved");
        }

        Department dept = request.getDepartment();
        double maxAllowed = dept.getYearlyAllocation() * 0.10;

        if (request.getRequestedAmount() > maxAllowed) {
            throw new IllegalArgumentException("Requested amount exceeds 10% of yearly allocation");
        }

        // Deduct and approve
        dept.setCurrentBudget(dept.getCurrentBudget() - request.getRequestedAmount());
        departmentRepository.save(dept);

        request.setStatus(Status.APPROVED);
        request.setApprovedBy(managerUsername);
        request.setLastUpdated(LocalDateTime.now());
        budgetRequestRepository.save(request);

        saveAudit("APPROVE", request, managerUsername);

        return request;
    }

    public BudgetRequest rejectRequest(Long id, String managerUsername) {
        BudgetRequest request = getRequestOrThrow(id);

        if (request.getStatus() != Status.PENDING) {
            throw new IllegalStateException("Only pending requests can be rejected");
        }

        request.setStatus(Status.REJECTED);
        request.setApprovedBy(managerUsername);
        request.setLastUpdated(LocalDateTime.now());
        budgetRequestRepository.save(request);

        saveAudit("REJECT", request, managerUsername);

        return request;
    }

    public List<BudgetRequest> getPendingRequests() {
        return budgetRequestRepository.findByStatus(Status.PENDING);
    }

    public List<AuditLog> getAuditLogs(String entityType) {
        return auditLogRepository.findByEntityType(entityType);
    }

    private BudgetRequest getRequestOrThrow(Long id) {
        Optional<BudgetRequest> optional = budgetRequestRepository.findById(id);
        if (optional.isEmpty()) {
            throw new IllegalArgumentException("BudgetRequest not found with ID: " + id);
        }
        return optional.get();
    }

    private void saveAudit(String action, BudgetRequest request, String changedBy) {
        AuditLog log = new AuditLog();
        log.setAction(action);
        log.setEntityId(request.getId());
        log.setEntityType("BudgetRequest");
        log.setOldValue(request.getStatus().toString());
        log.setNewValue(action);
        log.setChangedBy(changedBy);
        log.setTimestamp(LocalDateTime.now());
        auditLogRepository.save(log);
    }
}
